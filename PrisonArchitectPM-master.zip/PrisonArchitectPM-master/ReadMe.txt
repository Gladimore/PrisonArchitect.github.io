// Prison Architect Prison Manager (PAPM) v1.9.0.0
// by JPSIII
// Copyright 2015. All Rights Reserved
// YOU CAN DOWNLOAD DotNetZip library here:
// http://dotnetzip.codeplex.com/
///////////////////////////////////////////////////////////////////////////
//LICENSE 
//BY DOWNLOADING AND USING, YOU AGREE TO THE FOLLOWING TERMS: 
//If it is your intent to use this software for non-commercial purposes,  
//such as in academic research, this software is free and is covered under  
//the GNU GPL License, given here: <http://www.gnu.org/licenses/gpl.txt>  
//You agree with 3RDPARTY's Terms Of Service 
//found with their software. 
///////////////////////////////////////////////////////////////////////////

****************************
***    Quick Start       ***
****************************
The host PC It needs the .NET 4.5 Runtime
http://www.microsoft.com/en-us/download/details.aspx?id=30653
 
Prison Architect Prison Manager  default install path is
c:\Users\<USERNAME>\AppData\Local\Prison Architect Prison Manager

****************************
***    Testing Notes     ***
****************************
Tested with Prison Architect 02/07/2015
Tested on Windows 7 64bit
 
****************************
***  TROUBLESHOOTING     ***
****************************
